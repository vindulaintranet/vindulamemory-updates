export const SCHEMA_VERSION = "hm.vindula.browser-bridge.v1";
export const HOST_NAME = "com.vindula.memory.bridge";
export const HISTORY_LOOKBACK_MS = 1000 * 60 * 60 * 24 * 14;
export const HISTORY_LIMIT = 200;

export function buildBridgeMessage(command, payload) {
  return {
    schemaVersion: SCHEMA_VERSION,
    requestID: crypto.randomUUID(),
    command,
    payload,
  };
}

export function sanitizeText(text) {
  if (!text) {
    return null;
  }
  const normalized = String(text).replace(/\r\n/g, "\n").trim();
  return normalized.length === 0 ? null : normalized;
}

export function domainFromUrl(url) {
  try {
    return new URL(url).host || "unknown";
  } catch {
    return "unknown";
  }
}

export function buildTabArtifact(tab, { browser, profile, capturedAt, sourceGroupID = null }) {
  return {
    id: `browser-tab-${tab.id ?? crypto.randomUUID()}`,
    title: tab.title || tab.pendingUrl || tab.url || "Untitled Tab",
    url: tab.url || tab.pendingUrl || "",
    browser,
    profile,
    domain: domainFromUrl(tab.url || tab.pendingUrl || ""),
    capturedAt,
    position: typeof tab.index === "number" ? tab.index : 0,
    isPinned: Boolean(tab.pinned),
    sourceTabID: typeof tab.id === "number" ? tab.id : null,
    sourceWindowID: typeof tab.windowId === "number" ? tab.windowId : null,
    sourceGroupID,
  };
}

export function buildPagePayload({ captureKind, browser, profile, capturedAt, page, targetGroupID = null }) {
  return {
    captureKind,
    url: page.url,
    title: page.title || page.tabTitle || page.url,
    tabTitle: page.tabTitle || page.title || page.url,
    browser,
    profile,
    capturedAt,
    selectedText: sanitizeText(page.selectedText),
    pageText: sanitizeText(page.pageText),
    targetGroupID,
  };
}

export function buildWindowSnapshotPayload({ browser, profile, capturedAt, windowTitle, groups, ungroupedTabs }) {
  return {
    browser,
    profile,
    capturedAt,
    windowTitle,
    groups,
    ungroupedTabs,
  };
}

export function buildHistoryPayload({ browser, profile, importedAt, entries }) {
  return {
    browser,
    profile,
    importedAt,
    entries: entries.map((entry) => ({
      id: `history-${entry.id ?? crypto.randomUUID()}`,
      url: entry.url,
      title: entry.title || entry.url,
      browser,
      profile,
      visitedAt: new Date(entry.lastVisitTime).toISOString(),
      domain: domainFromUrl(entry.url),
    })),
  };
}

export function buildTabGroupCreatePayload({ title, browser, profile }) {
  return {
    title: sanitizeText(title) || "New Group",
    browser,
    profile,
  };
}

export function compareExtensionVersions(currentVersion, availableVersion) {
  const currentParts = parseVersionParts(currentVersion);
  const availableParts = parseVersionParts(availableVersion);
  if (!currentParts || !availableParts) {
    return 0;
  }

  const length = Math.max(currentParts.length, availableParts.length);
  for (let index = 0; index < length; index += 1) {
    const current = currentParts[index] ?? 0;
    const available = availableParts[index] ?? 0;
    if (current < available) return -1;
    if (current > available) return 1;
  }
  return 0;
}

function parseVersionParts(version) {
  if (typeof version !== "string" || !version.trim()) {
    return null;
  }
  const parts = version.trim().split(".");
  if (!parts.length) {
    return null;
  }
  const numbers = parts.map((part) => Number.parseInt(part, 10));
  return numbers.every((part) => Number.isFinite(part) && part >= 0) ? numbers : null;
}
