# Vindula Memory Extension

Chromium-first MV3 extension for saving links, page content, and browser state into Vindula Memory. The macOS app bundles and refreshes this unpacked extension copy automatically when Vindula Memory starts after an app update.

## Commands

- `save_current_page` stages the current link into a group
- `save_selection` saves selected text or page content into the Saved Content library
- `import_window_snapshot`
- `import_recent_history`

## Local install

1. Build and run the macOS app once so it installs the `Native Messaging` host manifest for `com.vindula.memory.bridge`.
2. In Vindula Memory, open `Settings > Extensão do Chrome` and click **Abrir Chrome para concluir**, or run `./apps/vindula-macos/script/prepare_browser_extension_install.sh`.
3. In Chromium/Chrome/Brave/Edge, load the shown folder as an unpacked extension.
4. After a Vindula Memory app update, reopen the app. It refreshes the extension folder automatically. If the extension was already loaded in Chrome, click **Reload** on Chrome's extensions page.
5. Use the keyboard shortcuts, extension action, or context menu entries to send links and content into Vindula Memory.

The extension id is pinned through the manifest key and should resolve to:

- `higokgfiajeaileoadpnafilbnmjfebe`
