import {
  buildBridgeMessage,
  buildHistoryPayload,
  buildPagePayload,
  buildTabArtifact,
  buildTabGroupCreatePayload,
  buildWindowSnapshotPayload,
  HISTORY_LIMIT,
  HISTORY_LOOKBACK_MS,
  HOST_NAME,
} from "./shared.js";

const BROWSER_NAME = "Chromium";
const PROFILE_NAME = "Default";
const SIDE_PANEL_PATH = "sidepanel.html";
const PANEL_STATE_KEY = "vindula-panel-state";

const CONTEXT_MENU_IDS = {
  saveCurrentPage: "vindula-save-current-page",
  saveSelection: "vindula-save-selection",
  importWindowSnapshot: "vindula-import-window-snapshot",
  importRecentHistory: "vindula-import-recent-history",
};

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.saveCurrentPage,
      title: "Save Link to Vindula…",
      contexts: ["page", "action"],
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.saveSelection,
      title: "Save Content to Vindula",
      contexts: ["selection", "page", "action"],
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.importWindowSnapshot,
      title: "Import Window Snapshot to Vindula",
      contexts: ["action"],
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.importRecentHistory,
      title: "Import Recent History to Vindula",
      contexts: ["action"],
    });
  });

  await chrome.storage.local.set({
    [PANEL_STATE_KEY]: {
      selectedGroupID: null,
      pendingCapture: null,
      activeMode: "tabs",
    },
  });
  await configureSidePanelBehavior();
});

chrome.runtime.onStartup?.addListener(async () => {
  await configureSidePanelBehavior();
});

chrome.action.onClicked.addListener(async (tab) => {
  await openPanelForCapture({ captureKind: "page", tab });
});

chrome.commands.onCommand.addListener(async (command) => {
  switch (command) {
    case "save_current_page":
      await openPanelForCapture({ captureKind: "page" });
      break;
    case "save_selection":
      await saveCurrentContent(null, false);
      break;
    case "import_window_snapshot":
      await handleImportWindowSnapshot();
      break;
    case "import_recent_history":
      await handleImportRecentHistory();
      break;
    default:
      break;
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  switch (info.menuItemId) {
    case CONTEXT_MENU_IDS.saveCurrentPage:
      await openPanelForCapture({ captureKind: "page", tab });
      break;
    case CONTEXT_MENU_IDS.saveSelection:
      await saveCurrentContent(tab, false);
      break;
    case CONTEXT_MENU_IDS.importWindowSnapshot:
      await handleImportWindowSnapshot();
      break;
    case CONTEXT_MENU_IDS.importRecentHistory:
      await handleImportRecentHistory();
      break;
    default:
      break;
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleRuntimeMessage(message)
    .then((response) => sendResponse(response))
    .catch((error) => {
      console.error("Vindula panel message failed:", error);
      sendResponse({ ok: false, message: error?.message || "Unexpected extension error." });
    });
  return true;
});

async function handleRuntimeMessage(message) {
  switch (message?.type) {
    case "panel:get-state":
      return replyWithState(await getPanelStateSnapshot());
    case "panel:select-group":
      await updatePanelState((current) => ({
        ...current,
        selectedGroupID: message.groupID || null,
      }));
      return replyWithState(await getPanelStateSnapshot());
    case "panel:create-group": {
      const response = await sendNativeMessage(
        buildBridgeMessage(
          "create_tab_group",
          buildTabGroupCreatePayload({
            title: message.title,
            browser: BROWSER_NAME,
            profile: PROFILE_NAME,
          }),
        ),
      );
      if (!response?.ok || !response.payload?.id) {
        return replyError(response?.message || "Could not create tab group.");
      }
      await updatePanelState((current) => ({
        ...current,
        selectedGroupID: response.payload.id,
      }));
      return replyWithState(await getPanelStateSnapshot(), response.message || "Created tab group.");
    }
    case "panel:capture-current-page":
      return openPanelForCapture({ captureKind: "page", openPanel: false });
    case "panel:capture-selection":
      return saveCurrentContent(null, false);
    case "panel:save-pending":
      return handleSavePendingCapture(message.groupID);
    case "panel:import-window-snapshot": {
      const response = await handleImportWindowSnapshot();
      return replyWithState(await getPanelStateSnapshot(), response?.message || "Imported window snapshot.");
    }
    case "panel:import-recent-history": {
      const response = await handleImportRecentHistory();
      return replyWithState(await getPanelStateSnapshot(), response?.message || "Imported recent history.");
    }
    default:
      return replyError("Unknown extension action.");
  }
}

async function openPanelForCapture({ captureKind = "page", tab = null, openPanel = true }) {
  const activeTab = tab?.id ? tab : await getActiveTab();
  if (!activeTab?.id) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "No active tab available.",
    });
    return replyError("No active tab available.");
  }

  if (openPanel) {
    const opened = await ensureSidePanelVisible(activeTab);
    if (!opened) {
      return replyError("Could not open the Vindula side panel in this browser.");
    }
  }

  const page = await extractPageFromTab(activeTab.id, false);
  if (!page?.url) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Could not read the current page.",
    });
    return replyError("Could not read the current page.");
  }

  const pendingCapture = buildPagePayload({
    captureKind,
    browser: BROWSER_NAME,
    profile: PROFILE_NAME,
    capturedAt: new Date().toISOString(),
    page: {
      ...page,
      tabTitle: activeTab.title,
    },
  });

  await updatePanelState((current) => ({
    ...current,
    pendingCapture,
    activeMode: "capture",
  }));

  if (openPanel) {
    await notifyPanelStateChanged();
  }

  return replyWithState(
    await getPanelStateSnapshot(),
    "Current link ready to save.",
  );
}

async function handleSavePendingCapture(groupID) {
  const panelState = await readPanelState();
  const snapshot = await getPanelSnapshot();
  const targetGroupID = groupID || panelState.selectedGroupID || snapshot.defaultGroupID;
  const pendingCapture = panelState.pendingCapture;

  if (!pendingCapture?.url) {
    return replyError("Load the current link before saving.");
  }

  const response = await sendNativeMessage(
    buildBridgeMessage("save_current_page", {
      ...pendingCapture,
      targetGroupID,
    }),
  );

  if (!response?.ok) {
    await showResponseFeedback(response, {
      successDetail: "Saved link to Vindula.",
      failureDetail: "Could not save link.",
    });
    return replyError(response?.message || "Could not save link.");
  }

  await updatePanelState((current) => ({
    ...current,
    selectedGroupID: targetGroupID,
    pendingCapture: null,
    activeMode: "tabs",
  }));

  await showResponseFeedback(response, {
    successDetail: "Saved link to Vindula.",
    failureDetail: "Could not save link.",
  });

  return replyWithState(await getPanelStateSnapshot(), response.message || "Saved link to group.");
}

async function saveCurrentContent(tab = null, openPanel = false) {
  const activeTab = tab?.id ? tab : await getActiveTab();
  if (!activeTab?.id) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "No active tab available.",
    });
    return replyError("No active tab available.");
  }

  if (openPanel) {
    const opened = await ensureSidePanelVisible(activeTab);
    if (!opened) {
      return replyError("Could not open the Vindula side panel in this browser.");
    }
  }

  const page = await extractPageFromTab(activeTab.id, false);
  if (!page?.url) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Could not read the current page.",
    });
    return replyError("Could not read the current page.");
  }

  const hasSelection = Boolean(page.selectedText?.trim());
  const payload = buildPagePayload({
    captureKind: hasSelection ? "selection" : "page",
    browser: BROWSER_NAME,
    profile: PROFILE_NAME,
    capturedAt: new Date().toISOString(),
    page: {
      ...page,
      tabTitle: activeTab.title,
    },
  });

  const response = await sendNativeMessage(
    buildBridgeMessage("save_selection", payload),
  );

  await showResponseFeedback(response, {
    successDetail: hasSelection ? "Saved selected content to Vindula." : "Saved page content to Vindula.",
    failureDetail: "Could not save page content.",
  });

  if (!response?.ok) {
    return replyError(response?.message || "Could not save page content.");
  }

  await updatePanelState((current) => ({
    ...current,
    activeMode: "tabs",
  }));

  return replyWithState(
    await getPanelStateSnapshot(),
    response.message || (hasSelection ? "Saved selected content." : "Saved page content."),
  );
}

async function handleImportWindowSnapshot() {
  const [windowTab] = await chrome.tabs.query({ currentWindow: true, active: true });
  if (!windowTab?.windowId) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "No browser window available.",
    });
    return replyError("No browser window available.");
  }

  const now = new Date().toISOString();
  const tabs = await chrome.tabs.query({ windowId: windowTab.windowId });
  const groupedTabs = new Map();
  const ungroupedTabs = [];

  for (const tab of tabs) {
    if (typeof tab.groupId === "number" && tab.groupId >= 0) {
      if (!groupedTabs.has(tab.groupId)) {
        const group = await chrome.tabGroups.get(tab.groupId);
        groupedTabs.set(tab.groupId, {
          id: `chrome-group-${tab.groupId}`,
          title: group.title || "Imported Group",
          color: group.color || null,
          tabs: [],
        });
      }
      groupedTabs.get(tab.groupId).tabs.push(
        buildTabArtifact(tab, {
          browser: BROWSER_NAME,
          profile: PROFILE_NAME,
          capturedAt: now,
          sourceGroupID: `chrome-group-${tab.groupId}`,
        }),
      );
    } else {
      ungroupedTabs.push(
        buildTabArtifact(tab, {
          browser: BROWSER_NAME,
          profile: PROFILE_NAME,
          capturedAt: now,
        }),
      );
    }
  }

  const response = await sendNativeMessage(
    buildBridgeMessage(
      "import_window_snapshot",
      buildWindowSnapshotPayload({
        browser: BROWSER_NAME,
        profile: PROFILE_NAME,
        capturedAt: now,
        windowTitle: windowTab.title || "Current Window",
        groups: Array.from(groupedTabs.values()),
        ungroupedTabs,
      }),
    ),
  );
  await showResponseFeedback(response, {
    successDetail: "Imported window snapshot into Vindula.",
    failureDetail: "Could not import the current window snapshot.",
  });
  return response;
}

async function handleImportRecentHistory() {
  const importedAt = new Date().toISOString();
  const entries = await chrome.history.search({
    text: "",
    maxResults: HISTORY_LIMIT,
    startTime: Date.now() - HISTORY_LOOKBACK_MS,
  });

  const response = await sendNativeMessage(
    buildBridgeMessage(
      "import_recent_history",
      buildHistoryPayload({
        browser: BROWSER_NAME,
        profile: PROFILE_NAME,
        importedAt,
        entries,
      }),
    ),
  );
  await showResponseFeedback(response, {
    successDetail: "Imported recent history into Vindula.",
    failureDetail: "Could not import recent history.",
  });
  return response;
}

async function getPanelStateSnapshot() {
  const [panelState, snapshot] = await Promise.all([
    readPanelState(),
    getPanelSnapshot(),
  ]);
  const groupIDs = new Set(snapshot.groups.map((group) => group.id));
  const selectedGroupID = groupIDs.has(panelState.selectedGroupID)
    ? panelState.selectedGroupID
    : snapshot.defaultGroupID;

  if (selectedGroupID !== panelState.selectedGroupID) {
    await updatePanelState((current) => ({
      ...current,
      selectedGroupID,
    }));
  }

  const activeMode =
    panelState.activeMode === "capture" && !panelState.pendingCapture
      ? "tabs"
      : (panelState.activeMode || "tabs");

  return {
    defaultGroupID: snapshot.defaultGroupID,
    selectedGroupID,
    pendingCapture: panelState.pendingCapture,
    groups: snapshot.groups,
    activeMode,
  };
}

async function configureSidePanelBehavior() {
  if (!chrome.sidePanel?.setPanelBehavior) {
    return;
  }
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (error) {
    console.warn("Vindula could not configure side panel behavior:", error);
  }
}

async function ensureSidePanelVisible(tab) {
  if (!chrome.sidePanel?.open) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "This browser does not support the extension side panel API.",
    });
    return false;
  }

  try {
    await chrome.sidePanel.open({ windowId: tab.windowId });
    return true;
  } catch (error) {
    console.error("Vindula failed to open side panel:", error);
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Chrome blocked the side panel from opening. Try reloading the extension once.",
    });
    return false;
  }
}

async function notifyPanelStateChanged() {
  try {
    await chrome.runtime.sendMessage({ type: "panel:get-state" });
  } catch {
    // Ignore when the side panel page is not yet open.
  }
}

async function getPanelSnapshot() {
  const response = await sendNativeMessage(buildBridgeMessage("list_tab_groups", {}));
  if (!response?.ok || !response.payload?.groups) {
    throw new Error(response?.message || "Could not load Vindula tab groups.");
  }
  return response.payload;
}

async function readPanelState() {
  const stored = await chrome.storage.local.get(PANEL_STATE_KEY);
  return stored[PANEL_STATE_KEY] || {
    selectedGroupID: null,
    pendingCapture: null,
    activeMode: "tabs",
  };
}

async function updatePanelState(updater) {
  const current = await readPanelState();
  const next = typeof updater === "function" ? updater(current) : updater;
  await chrome.storage.local.set({ [PANEL_STATE_KEY]: next });
  return next;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ currentWindow: true, active: true });
  return tab;
}

async function extractPageFromTab(tabId, selectionOnly) {
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (selectionOnlyFlag) => {
      const selectedText = window.getSelection ? window.getSelection().toString() : "";
      const pageText = selectionOnlyFlag ? selectedText : (document.body?.innerText || "");
      return {
        title: document.title,
        url: window.location.href,
        selectedText,
        pageText,
      };
    },
    args: [selectionOnly],
  });
  return injection?.result ?? null;
}

async function sendNativeMessage(message) {
  try {
    return await chrome.runtime.sendNativeMessage(HOST_NAME, message);
  } catch (error) {
    console.error("Vindula native messaging failed:", error);
    return null;
  }
}

async function showResponseFeedback(response, { successDetail, failureDetail }) {
  if (response?.ok) {
    await showActionFeedback({
      ok: true,
      title: "Vindula Memory",
      detail: response.message || successDetail,
    });
    return;
  }

  await showActionFeedback({
    ok: false,
      title: "Vindula Memory",
    detail: response?.message || failureDetail,
  });
}

async function showActionFeedback({ ok, title, detail }) {
  const badgeText = ok ? "OK" : "ERR";
  const badgeColor = ok ? "#2E7D32" : "#B3261E";
  const fullTitle = detail ? `${title}\n${detail}` : title;

  await chrome.action.setBadgeBackgroundColor({ color: badgeColor });
  await chrome.action.setBadgeText({ text: badgeText });
  await chrome.action.setTitle({ title: fullTitle });

  setTimeout(() => {
    chrome.action.setBadgeText({ text: "" });
    chrome.action.setTitle({ title });
  }, 3500);
}

function replyWithState(state, message = "") {
  return {
    ok: true,
    message,
    state,
  };
}

function replyError(message) {
  return {
    ok: false,
    message,
  };
}
