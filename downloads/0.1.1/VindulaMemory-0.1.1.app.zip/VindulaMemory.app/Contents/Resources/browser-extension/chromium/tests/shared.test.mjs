import test from "node:test";
import assert from "node:assert/strict";

import {
  buildBridgeMessage,
  buildHistoryPayload,
  buildPagePayload,
  buildTabArtifact,
  buildTabGroupCreatePayload,
  buildWindowSnapshotPayload,
  domainFromUrl,
  sanitizeText,
} from "../shared.js";

test("sanitizeText trims and normalizes empty strings", () => {
  assert.equal(sanitizeText("  hello\r\nworld  "), "hello\nworld");
  assert.equal(sanitizeText("   "), null);
});

test("buildBridgeMessage emits schema and request id", () => {
  const message = buildBridgeMessage("save_current_page", { url: "https://example.com" });
  assert.equal(message.schemaVersion, "hm.vindula.browser-bridge.v1");
  assert.equal(message.command, "save_current_page");
  assert.ok(message.requestID);
});

test("build page payload keeps selection and page content", () => {
  const payload = buildPagePayload({
    captureKind: "selection",
    browser: "Chromium",
    profile: "Default",
    capturedAt: "2026-04-21T12:00:00Z",
    page: {
      url: "https://example.com/article",
      title: "Example Article",
      tabTitle: "Example Article",
      selectedText: "Important passage",
      pageText: "Full document text",
    },
    targetGroupID: "tab-group-inbox",
  });
  assert.equal(payload.captureKind, "selection");
  assert.equal(payload.selectedText, "Important passage");
  assert.equal(payload.pageText, "Full document text");
  assert.equal(payload.targetGroupID, "tab-group-inbox");
});

test("build tab artifact derives metadata from the URL", () => {
  const artifact = buildTabArtifact(
    { id: 42, index: 2, url: "https://example.com/docs", title: "Docs", pinned: true, windowId: 7 },
    { browser: "Chromium", profile: "Default", capturedAt: "2026-04-21T12:00:00Z", sourceGroupID: "chrome-group-1" },
  );
  assert.equal(artifact.domain, "example.com");
  assert.equal(artifact.sourceTabID, 42);
  assert.equal(artifact.sourceGroupID, "chrome-group-1");
});

test("build history and window payloads preserve batch metadata", () => {
  const history = buildHistoryPayload({
    browser: "Chromium",
    profile: "Default",
    importedAt: "2026-04-21T12:00:00Z",
    entries: [{ id: "a", url: "https://example.com", title: "Example", lastVisitTime: Date.parse("2026-04-21T11:00:00Z") }],
  });
  const snapshot = buildWindowSnapshotPayload({
    browser: "Chromium",
    profile: "Default",
    capturedAt: "2026-04-21T12:00:00Z",
    windowTitle: "Work Window",
    groups: [],
    ungroupedTabs: [],
  });

  assert.equal(history.entries.length, 1);
  assert.equal(history.entries[0].domain, "example.com");
  assert.equal(snapshot.windowTitle, "Work Window");
});

test("domainFromUrl falls back for invalid urls", () => {
  assert.equal(domainFromUrl("not a url"), "unknown");
});

test("buildTabGroupCreatePayload normalizes the group title", () => {
  const payload = buildTabGroupCreatePayload({
    title: "  Reading Queue  ",
    browser: "Chromium",
    profile: "Default",
  });
  assert.equal(payload.title, "Reading Queue");
});
