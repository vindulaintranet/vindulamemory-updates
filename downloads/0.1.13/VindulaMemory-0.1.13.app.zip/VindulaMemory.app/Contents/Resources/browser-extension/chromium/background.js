import {
  buildBridgeMessage,
  buildHistoryPayload,
  buildPagePayload,
  compareExtensionVersions,
  buildTabArtifact,
  buildTabGroupCreatePayload,
  buildWindowSnapshotPayload,
  HISTORY_LIMIT,
  HISTORY_LOOKBACK_MS,
  HOST_NAME,
} from "./shared.js";

const BROWSER_NAME = "Chromium";
const PROFILE_NAME = "Default";
const SIDE_PANEL_PATH = "sidepanel.html";
const PANEL_STATE_KEY = "vindula-panel-state";
const EXTENSION_SETTINGS_KEY = "vindula-extension-settings";

const DEFAULT_EXTENSION_SETTINGS = {
  autoImportTabs: false,
  autoHistorySync: false,
  historyBackfillMode: "from-now",
  tabsImportTrigger: "startup",
  lastHistorySyncAt: null,
  historyItemsImportedToday: 0,
};

const HISTORY_BACKFILL_MODES = {
  "from-now": 0,
  "7-days": 1000 * 60 * 60 * 24 * 7,
  "14-days": HISTORY_LOOKBACK_MS,
};

const CONTEXT_MENU_IDS = {
  saveCurrentPage: "vindula-save-current-page",
  saveSelection: "vindula-save-selection",
  importWindowSnapshot: "vindula-import-window-snapshot",
  importRecentHistory: "vindula-import-recent-history",
};

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.saveCurrentPage,
      title: "Salvar link no Vindula…",
      contexts: ["page", "action"],
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.saveSelection,
      title: "Salvar conteúdo no Vindula",
      contexts: ["selection", "page", "action"],
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.importWindowSnapshot,
      title: "Importar janela para o Vindula",
      contexts: ["action"],
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.importRecentHistory,
      title: "Importar histórico recente",
      contexts: ["action"],
    });
  });

  const existingSettings = await readExtensionSettings();
  await chrome.storage.local.set({
    [PANEL_STATE_KEY]: {
      selectedGroupID: null,
      pendingCapture: null,
      activeMode: "tabs",
    },
    [EXTENSION_SETTINGS_KEY]: existingSettings,
  });
  await configureSidePanelBehavior();
});

chrome.runtime.onStartup?.addListener(async () => {
  await configureSidePanelBehavior();
  await importWindowSnapshotOnStartupIfEnabled();
});

chrome.history?.onVisited?.addListener((historyItem) => {
  handleVisitedHistoryItem(historyItem).catch((error) => {
    console.warn("Vindula history auto-sync failed:", error);
  });
});

chrome.action.onClicked.addListener(async (tab) => {
  await openPanelForCapture({ captureKind: "page", tab });
});

chrome.commands.onCommand.addListener(async (command) => {
  switch (command) {
    case "save_current_page":
      await openPanelForCapture({ captureKind: "page" });
      break;
    case "save_selection":
      await saveCurrentContent(null, false);
      break;
    case "import_window_snapshot":
      await handleImportWindowSnapshot();
      break;
    case "import_recent_history":
      await handleImportRecentHistory();
      break;
    default:
      break;
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  switch (info.menuItemId) {
    case CONTEXT_MENU_IDS.saveCurrentPage:
      await openPanelForCapture({ captureKind: "page", tab });
      break;
    case CONTEXT_MENU_IDS.saveSelection:
      await saveCurrentContent(tab, false);
      break;
    case CONTEXT_MENU_IDS.importWindowSnapshot:
      await handleImportWindowSnapshot();
      break;
    case CONTEXT_MENU_IDS.importRecentHistory:
      await handleImportRecentHistory();
      break;
    default:
      break;
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleRuntimeMessage(message)
    .then((response) => sendResponse(response))
    .catch((error) => {
      console.error("Vindula panel message failed:", error);
      sendResponse({ ok: false, message: error?.message || "Erro inesperado na extensão." });
    });
  return true;
});

async function handleRuntimeMessage(message) {
  switch (message?.type) {
    case "panel:get-state":
      return replyWithState(await getPanelStateSnapshot());
    case "panel:select-group":
      await updatePanelState((current) => ({
        ...current,
        selectedGroupID: message.groupID || null,
      }));
      return replyWithState(await getPanelStateSnapshot());
    case "panel:create-group": {
      const response = await sendNativeMessage(
        buildBridgeMessage(
          "create_tab_group",
          buildTabGroupCreatePayload({
            title: message.title,
            browser: BROWSER_NAME,
            profile: PROFILE_NAME,
          }),
        ),
      );
      if (!response?.ok || !response.payload?.id) {
        return replyError(response?.message || "Não consegui criar o grupo.");
      }
      await updatePanelState((current) => ({
        ...current,
        selectedGroupID: response.payload.id,
      }));
      return replyWithState(await getPanelStateSnapshot(), response.message || "Grupo criado.");
    }
    case "panel:capture-current-page":
      return openPanelForCapture({ captureKind: "page", openPanel: false });
    case "panel:capture-selection":
      return saveCurrentContent(null, false);
    case "panel:save-pending":
      return handleSavePendingCapture(message.groupID);
    case "panel:import-window-snapshot": {
      const response = await handleImportWindowSnapshot();
      return replyWithState(await getPanelStateSnapshot(), response?.message || "Janela importada.");
    }
    case "panel:import-recent-history": {
      const response = await handleImportRecentHistory({ mode: message.mode });
      return replyWithState(await getPanelStateSnapshot(), response?.message || "Histórico importado.");
    }
    case "panel:update-settings": {
      const response = await handleUpdateSettings(message.settings || {}, {
        runInitialHistoryImport: Boolean(message.runInitialHistoryImport),
      });
      return replyWithState(await getPanelStateSnapshot(), response.message);
    }
    default:
      return replyError("Ação da extensão desconhecida.");
  }
}

async function openPanelForCapture({ captureKind = "page", tab = null, openPanel = true }) {
  const activeTab = tab?.id ? tab : await getActiveTab();
  if (!activeTab?.id) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Nenhuma aba ativa encontrada.",
    });
    return replyError("Nenhuma aba ativa encontrada.");
  }

  if (openPanel) {
    const opened = await ensureSidePanelVisible(activeTab);
    if (!opened) {
      return replyError("Não consegui abrir o painel lateral nesse navegador.");
    }
  }

  const page = await extractPageFromTab(activeTab.id, false);
  if (!page?.url) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Não consegui ler a página atual.",
    });
    return replyError("Não consegui ler a página atual.");
  }

  const pendingCapture = buildPagePayload({
    captureKind,
    browser: BROWSER_NAME,
    profile: PROFILE_NAME,
    capturedAt: new Date().toISOString(),
    page: {
      ...page,
      tabTitle: activeTab.title,
    },
  });

  await updatePanelState((current) => ({
    ...current,
    pendingCapture,
    activeMode: "capture",
  }));

  if (openPanel) {
    await notifyPanelStateChanged();
  }

  return replyWithState(
    await getPanelStateSnapshot(),
    "Link atual pronto para salvar.",
  );
}

async function handleSavePendingCapture(groupID) {
  const panelState = await readPanelState();
  const snapshot = await getPanelSnapshot();
  const targetGroupID = groupID || panelState.selectedGroupID || snapshot.defaultGroupID;
  const pendingCapture = panelState.pendingCapture;

  if (!pendingCapture?.url) {
    return replyError("Carregue o link atual antes de salvar.");
  }

  const response = await sendNativeMessage(
    buildBridgeMessage("save_current_page", {
      ...pendingCapture,
      targetGroupID,
    }),
  );

  if (!response?.ok) {
    await showResponseFeedback(response, {
      successDetail: "Link salvo no Vindula.",
      failureDetail: "Não consegui salvar o link.",
    });
    return replyError(response?.message || "Não consegui salvar o link.");
  }

  await updatePanelState((current) => ({
    ...current,
    selectedGroupID: targetGroupID,
    pendingCapture: null,
    activeMode: "tabs",
  }));

  await showResponseFeedback(response, {
    successDetail: "Link salvo no Vindula.",
    failureDetail: "Não consegui salvar o link.",
  });

  return replyWithState(await getPanelStateSnapshot(), response.message || "Link salvo no grupo.");
}

async function saveCurrentContent(tab = null, openPanel = false) {
  const activeTab = tab?.id ? tab : await getActiveTab();
  if (!activeTab?.id) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Nenhuma aba ativa encontrada.",
    });
    return replyError("Nenhuma aba ativa encontrada.");
  }

  if (openPanel) {
    const opened = await ensureSidePanelVisible(activeTab);
    if (!opened) {
      return replyError("Não consegui abrir o painel lateral nesse navegador.");
    }
  }

  const page = await extractPageFromTab(activeTab.id, false);
  if (!page?.url) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Não consegui ler a página atual.",
    });
    return replyError("Não consegui ler a página atual.");
  }

  const hasSelection = Boolean(page.selectedText?.trim());
  const payload = buildPagePayload({
    captureKind: hasSelection ? "selection" : "page",
    browser: BROWSER_NAME,
    profile: PROFILE_NAME,
    capturedAt: new Date().toISOString(),
    page: {
      ...page,
      tabTitle: activeTab.title,
    },
  });

  const response = await sendNativeMessage(
    buildBridgeMessage("save_selection", payload),
  );

  await showResponseFeedback(response, {
    successDetail: hasSelection ? "Seleção salva no Vindula." : "Página salva no Vindula.",
    failureDetail: "Não consegui salvar o conteúdo.",
  });

  if (!response?.ok) {
    return replyError(response?.message || "Não consegui salvar o conteúdo.");
  }

  await updatePanelState((current) => ({
    ...current,
    activeMode: "tabs",
  }));

  return replyWithState(
    await getPanelStateSnapshot(),
    response.message || (hasSelection ? "Seleção salva." : "Página salva."),
  );
}

async function handleImportWindowSnapshot({ showFeedback = true } = {}) {
  const [windowTab] = await chrome.tabs.query({ currentWindow: true, active: true });
  if (!windowTab?.windowId) {
    if (showFeedback) {
      await showActionFeedback({
        ok: false,
        title: "Vindula Memory",
        detail: "Nenhuma janela do navegador encontrada.",
      });
    }
    return replyError("Nenhuma janela do navegador encontrada.");
  }

  const now = new Date().toISOString();
  const tabs = await chrome.tabs.query({ windowId: windowTab.windowId });
  const groupedTabs = new Map();
  const ungroupedTabs = [];

  for (const tab of tabs) {
    if (typeof tab.groupId === "number" && tab.groupId >= 0) {
      if (!groupedTabs.has(tab.groupId)) {
        const group = await chrome.tabGroups.get(tab.groupId);
        groupedTabs.set(tab.groupId, {
          id: `chrome-group-${tab.groupId}`,
          title: group.title || "Grupo importado",
          color: group.color || null,
          tabs: [],
        });
      }
      groupedTabs.get(tab.groupId).tabs.push(
        buildTabArtifact(tab, {
          browser: BROWSER_NAME,
          profile: PROFILE_NAME,
          capturedAt: now,
          sourceGroupID: `chrome-group-${tab.groupId}`,
        }),
      );
    } else {
      ungroupedTabs.push(
        buildTabArtifact(tab, {
          browser: BROWSER_NAME,
          profile: PROFILE_NAME,
          capturedAt: now,
        }),
      );
    }
  }

  const response = await sendNativeMessage(
    buildBridgeMessage(
      "import_window_snapshot",
      buildWindowSnapshotPayload({
        browser: BROWSER_NAME,
        profile: PROFILE_NAME,
        capturedAt: now,
        windowTitle: windowTab.title || "Janela atual",
        groups: Array.from(groupedTabs.values()),
        ungroupedTabs,
      }),
    ),
  );
  if (showFeedback) {
    await showResponseFeedback(response, {
      successDetail: "Janela importada para o Vindula.",
      failureDetail: "Não consegui importar a janela atual.",
    });
  }
  return response;
}

async function handleImportRecentHistory({ showFeedback = true, mode = "14-days" } = {}) {
  const importedAt = new Date().toISOString();
  const lookbackMs = HISTORY_BACKFILL_MODES[mode] ?? HISTORY_LOOKBACK_MS;
  const entries = lookbackMs > 0
    ? await chrome.history.search({
        text: "",
        maxResults: HISTORY_LIMIT,
        startTime: Date.now() - lookbackMs,
      })
    : [];

  const response = await sendNativeMessage(
    buildBridgeMessage(
      "import_recent_history",
      buildHistoryPayload({
        browser: BROWSER_NAME,
        profile: PROFILE_NAME,
        importedAt,
        entries,
      }),
    ),
  );
  if (response?.ok) {
    await updateHistorySyncStats(importedAt, entries.length);
  }

  if (showFeedback) {
    await showResponseFeedback(response, {
      successDetail: entries.length > 0
        ? "Histórico recente importado para o Vindula."
        : "Histórico automático ativado para novas visitas.",
      failureDetail: "Não consegui importar o histórico recente.",
    });
  }
  return response;
}

async function handleUpdateSettings(partialSettings, { runInitialHistoryImport = false } = {}) {
  const current = await readExtensionSettings();
  const next = sanitizeExtensionSettings({ ...current, ...partialSettings });
  await chrome.storage.local.set({ [EXTENSION_SETTINGS_KEY]: next });

  if (runInitialHistoryImport && next.autoHistorySync && next.historyBackfillMode !== "from-now") {
    await handleImportRecentHistory({
      showFeedback: false,
      mode: next.historyBackfillMode,
    });
  }

  return { ok: true, message: "Configurações atualizadas." };
}

async function importWindowSnapshotOnStartupIfEnabled() {
  const settings = await readExtensionSettings();
  if (!settings.autoImportTabs || settings.tabsImportTrigger !== "startup") {
    return;
  }
  await handleImportWindowSnapshot({ showFeedback: false });
}

async function handleVisitedHistoryItem(historyItem) {
  const settings = await readExtensionSettings();
  if (!settings.autoHistorySync || !historyItem?.url) {
    return;
  }

  const importedAt = new Date().toISOString();
  const entry = {
    id: historyItem.id,
    url: historyItem.url,
    title: historyItem.title || historyItem.url,
    lastVisitTime: historyItem.lastVisitTime || Date.now(),
  };

  const response = await sendNativeMessage(
    buildBridgeMessage(
      "import_recent_history",
      buildHistoryPayload({
        browser: BROWSER_NAME,
        profile: PROFILE_NAME,
        importedAt,
        entries: [entry],
      }),
    ),
  );

  if (response?.ok) {
    await updateHistorySyncStats(importedAt, 1);
    await notifyPanelStateChanged();
  }
}

async function readExtensionSettings() {
  const stored = await chrome.storage.local.get(EXTENSION_SETTINGS_KEY);
  return sanitizeExtensionSettings(stored[EXTENSION_SETTINGS_KEY] || DEFAULT_EXTENSION_SETTINGS);
}

function sanitizeExtensionSettings(settings) {
  const backfillMode = Object.hasOwn(HISTORY_BACKFILL_MODES, settings?.historyBackfillMode)
    ? settings.historyBackfillMode
    : DEFAULT_EXTENSION_SETTINGS.historyBackfillMode;
  const tabsImportTrigger = settings?.tabsImportTrigger === "startup"
    ? "startup"
    : DEFAULT_EXTENSION_SETTINGS.tabsImportTrigger;

  return {
    autoImportTabs: Boolean(settings?.autoImportTabs),
    autoHistorySync: Boolean(settings?.autoHistorySync),
    historyBackfillMode: backfillMode,
    tabsImportTrigger,
    lastHistorySyncAt: typeof settings?.lastHistorySyncAt === "string"
      ? settings.lastHistorySyncAt
      : null,
    historyItemsImportedToday: Number.isFinite(settings?.historyItemsImportedToday)
      ? Math.max(0, Math.trunc(settings.historyItemsImportedToday))
      : 0,
  };
}

async function updateHistorySyncStats(importedAt, importedCount) {
  const current = await readExtensionSettings();
  const previousCount = isSameUtcDate(current.lastHistorySyncAt, importedAt)
    ? current.historyItemsImportedToday
    : 0;
  await chrome.storage.local.set({
    [EXTENSION_SETTINGS_KEY]: {
      ...current,
      lastHistorySyncAt: importedAt,
      historyItemsImportedToday: previousCount + Math.max(0, importedCount),
    },
  });
}

function isSameUtcDate(left, right) {
  if (!left || !right) return false;
  return String(left).slice(0, 10) === String(right).slice(0, 10);
}

async function getPanelStateSnapshot() {
  const [panelState, snapshot] = await Promise.all([
    readPanelState(),
    getPanelSnapshot(),
  ]);
  const groupIDs = new Set(snapshot.groups.map((group) => group.id));
  const selectedGroupID = groupIDs.has(panelState.selectedGroupID)
    ? panelState.selectedGroupID
    : snapshot.defaultGroupID;

  if (selectedGroupID !== panelState.selectedGroupID) {
    await updatePanelState((current) => ({
      ...current,
      selectedGroupID,
    }));
  }

  const validModes = new Set(["tabs", "search", "capture", "settings"]);
  const storedMode = panelState.activeMode === "more" ? "settings" : panelState.activeMode;
  const activeMode = validModes.has(storedMode) ? storedMode : "tabs";

  return {
    defaultGroupID: snapshot.defaultGroupID,
    selectedGroupID,
    pendingCapture: panelState.pendingCapture,
    groups: snapshot.groups,
    activeMode,
    extensionVersionStatus: await getExtensionVersionStatus(),
    settings: await readExtensionSettings(),
  };
}

async function getExtensionVersionStatus() {
  const currentVersion = chrome.runtime.getManifest()?.version || null;
  const response = await sendNativeMessage(
    buildBridgeMessage("ping", { extensionVersion: currentVersion }),
  );
  const availableVersion = response?.payload?.installedExtensionVersion || null;
  return {
    currentVersion,
    availableVersion,
    hostReady: Boolean(response?.ok),
    updateAvailable: compareExtensionVersions(currentVersion, availableVersion) < 0,
  };
}

async function configureSidePanelBehavior() {
  if (!chrome.sidePanel?.setPanelBehavior) {
    return;
  }
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (error) {
    console.warn("Vindula could not configure side panel behavior:", error);
  }
}

async function ensureSidePanelVisible(tab) {
  if (!chrome.sidePanel?.open) {
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "Este navegador não suporta o painel lateral da extensão.",
    });
    return false;
  }

  try {
    await chrome.sidePanel.open({ windowId: tab.windowId });
    return true;
  } catch (error) {
    console.error("Vindula failed to open side panel:", error);
    await showActionFeedback({
      ok: false,
      title: "Vindula Memory",
      detail: "O Chrome bloqueou a abertura do painel. Recarregue a extensão uma vez.",
    });
    return false;
  }
}

async function notifyPanelStateChanged() {
  try {
    await chrome.runtime.sendMessage({ type: "panel:get-state" });
  } catch {
    // Ignore when the side panel page is not yet open.
  }
}

async function getPanelSnapshot() {
  const response = await sendNativeMessage(buildBridgeMessage("list_tab_groups", {}));
  if (!response?.ok || !response.payload?.groups) {
    throw new Error(response?.message || "Não consegui carregar os grupos do Vindula.");
  }
  return response.payload;
}

async function readPanelState() {
  const stored = await chrome.storage.local.get(PANEL_STATE_KEY);
  return stored[PANEL_STATE_KEY] || {
    selectedGroupID: null,
    pendingCapture: null,
    activeMode: "tabs",
  };
}

async function updatePanelState(updater) {
  const current = await readPanelState();
  const next = typeof updater === "function" ? updater(current) : updater;
  await chrome.storage.local.set({ [PANEL_STATE_KEY]: next });
  return next;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ currentWindow: true, active: true });
  return tab;
}

async function extractPageFromTab(tabId, selectionOnly) {
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (selectionOnlyFlag) => {
      const selectedText = window.getSelection ? window.getSelection().toString() : "";
      const pageText = selectionOnlyFlag ? selectedText : (document.body?.innerText || "");
      return {
        title: document.title,
        url: window.location.href,
        selectedText,
        pageText,
      };
    },
    args: [selectionOnly],
  });
  return injection?.result ?? null;
}

async function sendNativeMessage(message) {
  try {
    return await chrome.runtime.sendNativeMessage(HOST_NAME, message);
  } catch (error) {
    console.error("Vindula native messaging failed:", error);
    return null;
  }
}

async function showResponseFeedback(response, { successDetail, failureDetail }) {
  if (response?.ok) {
    await showActionFeedback({
      ok: true,
      title: "Vindula Memory",
      detail: response.message || successDetail,
    });
    return;
  }

  await showActionFeedback({
    ok: false,
      title: "Vindula Memory",
    detail: response?.message || failureDetail,
  });
}

async function showActionFeedback({ ok, title, detail }) {
  const badgeText = ok ? "OK" : "!";
  const badgeColor = ok ? "#2E7D32" : "#B3261E";
  const fullTitle = detail ? `${title}\n${detail}` : title;

  await chrome.action.setBadgeBackgroundColor({ color: badgeColor });
  await chrome.action.setBadgeText({ text: badgeText });
  await chrome.action.setTitle({ title: fullTitle });

  setTimeout(() => {
    chrome.action.setBadgeText({ text: "" });
    chrome.action.setTitle({ title });
  }, 3500);
}

function replyWithState(state, message = "") {
  return {
    ok: true,
    message,
    state,
  };
}

function replyError(message) {
  return {
    ok: false,
    message,
  };
}
