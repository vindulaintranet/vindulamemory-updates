const elements = {
  connectionDot: document.querySelector("#connection-dot"),
  searchInput: document.querySelector("#search-input"),
  searchScope: document.querySelector("#search-scope"),
  scopeDropdown: document.querySelector("#scope-dropdown"),
  createGroupForm: document.querySelector("#create-group-form"),
  createGroupInput: document.querySelector("#create-group-input"),
  homeOverview: document.querySelector("#home-overview"),
  groupsList: document.querySelector("#groups-list"),
  quickActions: document.querySelector("#quick-actions"),
  capturePreview: document.querySelector("#capture-preview"),
  groupSelect: document.querySelector("#group-select"),
  saveButton: document.querySelector("#save-button"),
  capturePageButton: document.querySelector("#capture-page-button"),
  captureSelectionButton: document.querySelector("#capture-selection-button"),
  updateBanner: document.querySelector("#extension-update-banner"),
  updateCopy: document.querySelector("#extension-update-copy"),
  updateButton: document.querySelector("#extension-update-button"),
  statusToast: document.querySelector("#status-toast"),
  autoTabsToggle: document.querySelector("#auto-tabs-toggle"),
  tabsTriggerSelect: document.querySelector("#tabs-trigger-select"),
  settingsImportWindow: document.querySelector("#settings-import-window"),
  autoHistoryToggle: document.querySelector("#auto-history-toggle"),
  historyBackfillOptions: document.querySelector("#history-backfill-options"),
  historySyncStatus: document.querySelector("#history-sync-status"),
};

let panelState = {
  defaultGroupID: null,
  selectedGroupID: null,
  pendingCapture: null,
  groups: [],
  settings: {
    autoImportTabs: false,
    autoHistorySync: false,
    historyBackfillMode: "from-now",
    tabsImportTrigger: "startup",
    lastHistorySyncAt: null,
    historyItemsImportedToday: 0,
  },
};

let uiState = {
  activeMode: "tabs",
  query: "",
  openGroupIDs: new Set(),
  searchScope: "all",
  scopeDropdownOpen: false,
};

let statusResetTimer = null;

document.addEventListener("DOMContentLoaded", async () => {
  bindEvents();
  await refreshState();
});

chrome.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName !== "local" || !changes["vindula-panel-state"]) {
    return;
  }
  await refreshState({ preserveStatus: true });
});

function bindEvents() {
  // Search
  elements.searchInput.addEventListener("input", (event) => {
    uiState.query = event.target.value.trim().toLowerCase();
    if (uiState.activeMode !== "tabs") {
      switchMode("tabs");
    }
    renderTabsMode();
  });

  // Scope dropdown
  elements.searchScope.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleScopeDropdown();
  });

  elements.scopeDropdown.addEventListener("click", (event) => {
    const option = event.target.closest("[data-scope]");
    if (!option) return;
    const scope = option.dataset.scope;
    uiState.searchScope = scope;
    elements.searchScope.innerHTML = `${scopeLabel(scope)} <span style="font-size:8px">▾</span>`;
    elements.scopeDropdown.querySelectorAll(".scope-option").forEach((el) => {
      el.classList.toggle("is-active", el.dataset.scope === scope);
    });
    closeScopeDropdown();
  });

  document.addEventListener("click", () => closeScopeDropdown());

  // Create group
  elements.createGroupForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const title = elements.createGroupInput.value.trim();
    if (!title) {
      setStatus("Digite um nome para o grupo.", false);
      return;
    }
    const response = await sendAndApply("panel:create-group", { title });
    if (response?.ok) {
      elements.createGroupInput.value = "";
      if (response.state?.selectedGroupID) {
        uiState.openGroupIDs.add(response.state.selectedGroupID);
      }
    }
  });

  // Group select (capture mode)
  elements.groupSelect.addEventListener("change", async (event) => {
    const groupID = event.target.value;
    uiState.openGroupIDs.add(groupID);
    await sendAndApply("panel:select-group", { groupID });
  });

  // Save / capture actions
  elements.saveButton.addEventListener("click", async () => {
    const response = await sendAndApply("panel:save-pending", {
      groupID: elements.groupSelect.value,
    });
    if (response?.ok) {
      switchMode("tabs");
    }
  });

  elements.capturePageButton.addEventListener("click", async () => {
    await sendAndApply("panel:capture-current-page");
  });

  elements.captureSelectionButton.addEventListener("click", async () => {
    await sendAndApply("panel:capture-selection");
  });

  elements.updateButton.addEventListener("click", async () => {
    await chrome.tabs.create({ url: "chrome://extensions" });
  });

  elements.autoTabsToggle.addEventListener("change", async (event) => {
    await updateSettings({ autoImportTabs: event.target.checked });
  });

  elements.tabsTriggerSelect.addEventListener("change", async (event) => {
    await updateSettings({ tabsImportTrigger: event.target.value });
  });

  elements.settingsImportWindow.addEventListener("click", async () => {
    await sendAndApply("panel:import-window-snapshot");
  });

  elements.autoHistoryToggle.addEventListener("change", async (event) => {
    await updateSettings(
      { autoHistorySync: event.target.checked },
      { runInitialHistoryImport: event.target.checked },
    );
  });

  elements.historyBackfillOptions.addEventListener("click", async (event) => {
    const option = event.target.closest("[data-history-mode]");
    if (!option) return;
    const historyBackfillMode = option.dataset.historyMode;
    await updateSettings(
      { historyBackfillMode },
      {
        runInitialHistoryImport:
          panelState.settings.autoHistorySync && historyBackfillMode !== "from-now",
      },
    );
  });

  // Bottom nav mode switching
  document.querySelectorAll("[data-mode]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const mode = btn.dataset.mode;
      switchMode(mode);
    });
  });

  // Group / link interactions
  elements.groupsList.addEventListener("click", async (event) => {
    const target = event.target.closest("[data-action]");
    if (!target) return;

    const action = target.dataset.action;
    switch (action) {
      case "toggle-group": {
        const groupID = target.dataset.groupId;
        toggleGroup(groupID);
        await sendAndApply("panel:select-group", { groupID });
        return;
      }
      case "open-url": {
        const url = target.dataset.url;
        if (url) {
          await chrome.tabs.create({ url });
        }
        return;
      }
      default:
        return;
    }
  });

  // Visibility refresh
  document.addEventListener("visibilitychange", async () => {
    if (!document.hidden) {
      await refreshState({ preserveStatus: true });
    }
  });
}

/* ─── Mode management ─── */

function switchMode(mode) {
  if (uiState.activeMode === mode) return;
  uiState.activeMode = mode;

  // Toggle sections
  document.querySelectorAll(".mode-section").forEach((section) => {
    section.classList.toggle("is-active", section.id === `mode-${mode}`);
  });

  // Toggle nav items
  document.querySelectorAll(".nav-item").forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.mode === mode);
  });

  // Render mode-specific content
  if (mode === "tabs") {
    renderTabsMode();
  } else if (mode === "capture") {
    renderCaptureMode();
  } else if (mode === "settings") {
    renderSettingsMode();
  }
}

/* ─── State sync ─── */

async function refreshState({ preserveStatus = false } = {}) {
  const response = await chrome.runtime.sendMessage({ type: "panel:get-state" });
  applyResponse(response, { preserveStatus });
}

async function sendAndApply(type, payload = {}) {
  const response = await chrome.runtime.sendMessage({ type, ...payload });
  applyResponse(response);
  return response;
}

async function updateSettings(settings, options = {}) {
  return sendAndApply("panel:update-settings", {
    settings,
    runInitialHistoryImport: Boolean(options.runInitialHistoryImport),
  });
}

function applyResponse(response, { preserveStatus = false } = {}) {
  if (response?.state) {
    panelState = response.state;
    syncOpenGroupState();
    if (response.state.activeMode && response.state.activeMode !== uiState.activeMode) {
      switchMode(response.state.activeMode);
    } else {
      render();
    }
  }

  if (response?.message) {
    setStatus(response.message, response.ok !== false);
  } else if (!preserveStatus) {
    setStatus("", true);
  }

  if (response?.ok === false && !response?.message) {
    setStatus("Não consegui concluir a ação.", false);
  }
}

function syncOpenGroupState() {
  const selectedGroupID = panelState.selectedGroupID || panelState.defaultGroupID;
  const knownGroupIDs = new Set(panelState.groups.map((g) => g.id));

  uiState.openGroupIDs = new Set(
    Array.from(uiState.openGroupIDs).filter((id) => knownGroupIDs.has(id)),
  );

  if (selectedGroupID && !uiState.openGroupIDs.size) {
    uiState.openGroupIDs.add(selectedGroupID);
  }

  if (selectedGroupID) {
    uiState.openGroupIDs.add(selectedGroupID);
  }
}

/* ─── Render ─── */

function render() {
  renderExtensionUpdateBanner();
  renderTabsMode();
  renderCaptureMode();
  renderSettingsMode();
}

function renderExtensionUpdateBanner() {
  const status = panelState.extensionVersionStatus;
  const isVisible = Boolean(status?.updateAvailable);
  elements.updateBanner.classList.toggle("is-visible", isVisible);
  elements.updateBanner.setAttribute("aria-hidden", isVisible ? "false" : "true");
  if (!isVisible) {
    elements.updateCopy.textContent = "";
    return;
  }

  const current = status.currentVersion || "desconhecida";
  const available = status.availableVersion || "nova";
  elements.updateCopy.textContent = `Esta extensão ainda está na versão ${current}. O app já preparou a versão ${available}. Abra as extensões do Chrome e clique em Recarregar.`;
}

/* ─── Tabs mode ─── */

function renderTabsMode() {
  const visibleGroups = buildVisibleGroups();
  renderHomeOverview();

  if (visibleGroups.length === 0) {
    elements.groupsList.innerHTML = `
      <div class="empty">
        ${uiState.query ? "Nenhum grupo encontrado nessa busca." : "Nenhum grupo ainda. Crie um abaixo."}
      </div>
    `;
  } else {
    elements.groupsList.innerHTML = visibleGroups
      .map(({ group, links }) => {
        const isSelected =
          group.id === (panelState.selectedGroupID || panelState.defaultGroupID);
        const isOpen = uiState.query ? true : uiState.openGroupIDs.has(group.id);
        const accent = escapeAttribute(groupAccent(group));

        return `
          <article
            class="group-item ${isSelected ? "is-selected" : ""} ${isOpen ? "is-open" : ""}"
          >
            <button
              class="group-header"
              data-action="toggle-group"
              data-group-id="${escapeAttribute(group.id)}"
              type="button"
            >
              <span
                class="group-accent-bar"
                style="background:${accent}"
              ></span>
              <div class="group-info">
                <span class="group-name">${escapeHtml(group.title)}</span>
                <span class="group-meta">${escapeHtml(groupSummary(group, links.length))}</span>
              </div>
              <span class="group-chevron">▾</span>
            </button>
            ${isOpen ? renderGroupLinks(links) : ""}
          </article>
        `;
      })
      .join("");
  }
}

function renderGroupLinks(links) {
  if (links.length === 0) {
    return `
      <div class="group-links">
        <div class="empty" style="text-align:left; padding: 8px 12px;">
          Nada salvo aqui ainda.
        </div>
      </div>
    `;
  }

  return `
    <div class="group-links">
      ${links
        .map(
          (item) => `
        <button
          class="link-item"
          data-action="open-url"
          data-url="${escapeAttribute(item.url)}"
          type="button"
        >
          <span
            class="link-favicon"
            style="background:${escapeAttribute(linkBadgeColor(item))}"
          >
            ${escapeHtml(linkBadgeLabel(item))}
          </span>
          <span class="link-info">
            <span class="link-title">${escapeHtml(item.title)}</span>
            <span class="link-url">${escapeHtml(item.meta)}</span>
          </span>
        </button>
      `,
        )
        .join("")}
    </div>
  `;
}

function buildVisibleGroups() {
  const query = uiState.query;
  const scope = uiState.searchScope;

  return panelState.groups
    .map((group) => {
      const links = group.tabs.map((tab) => ({
        id: tab.id,
        title: tab.title || tab.url,
        url: tab.url,
        domain: tab.domain,
        type: "link",
        meta: tab.domain || tab.url,
      }));

      if (!query) {
        return { group, links };
      }

      const groupMatch = group.title.toLowerCase().includes(query);
      const linkMatches = links.filter((item) => {
        return [item.title, item.url, item.domain, item.meta]
          .filter(Boolean)
          .some((value) => value.toLowerCase().includes(query));
      });

      if (scope === "groups") {
        return groupMatch ? { group, links } : null;
      }

      if (scope === "links") {
        return linkMatches.length > 0 ? { group, links: linkMatches } : null;
      }

      if (groupMatch) {
        return { group, links };
      }
      if (linkMatches.length > 0) {
        return { group, links: linkMatches };
      }
      return null;
    })
    .filter(Boolean);
}

function renderHomeOverview() {
  if (uiState.query) {
    elements.homeOverview.innerHTML = "";
    return;
  }

  const totalGroups = panelState.groups.length;
  const totalLinks = panelState.groups.reduce((sum, group) => sum + group.tabs.length, 0);
  elements.homeOverview.innerHTML = `
    <article class="home-card home-hero">
      <div class="home-hero-top">
        <p class="home-kicker">Memória ativa</p>
        <span class="home-shortcut">⌘⇧Y</span>
      </div>
      <div class="home-hero-copy">
        <h2 class="home-title">Pronto para guardar o que importa</h2>
        <p class="home-body">Use <strong>+</strong> para salvar página, conteúdo ou nota. Automações ficam em <strong>Config</strong>.</p>
      </div>
    </article>
    <article class="home-card">
      <span class="home-card-icon">▦</span>
      <div>
        <span class="home-card-title">Grupos recentes</span>
        <p class="home-card-body">Organize links por projeto ou contexto.</p>
      </div>
      <span class="home-count">${escapeHtml(totalGroups)}</span>
    </article>
    <article class="home-card">
      <span class="home-card-icon">◴</span>
      <div>
        <span class="home-card-title">Histórico</span>
        <p class="home-card-body">Ative sincronização automática em Config.</p>
      </div>
      <span class="home-count">${escapeHtml(panelState.settings.historyItemsImportedToday || 0)}</span>
    </article>
    <article class="home-card">
      <span class="home-card-icon">▤</span>
      <div>
        <span class="home-card-title">Conteúdos salvos</span>
        <p class="home-card-body">Páginas e textos ficam separados dos links.</p>
      </div>
      <span class="home-count">${escapeHtml(totalLinks)}</span>
    </article>
  `;
}

/* ─── Capture mode ─── */

function renderCaptureMode() {
  const capture = panelState.pendingCapture;
  const hasCapture = Boolean(capture);
  elements.quickActions.classList.toggle("hidden", hasCapture);
  elements.capturePreview.classList.toggle("hidden", !hasCapture);
  elements.groupSelect.classList.toggle("hidden", !hasCapture);
  elements.saveButton.classList.toggle("hidden", !hasCapture);
  elements.saveButton.disabled = !capture || panelState.groups.length === 0;

  // Sync group select
  const selectedGroupID = panelState.selectedGroupID || panelState.defaultGroupID;
  elements.groupSelect.innerHTML = panelState.groups
    .map((group) => {
      const label =
        group.systemRole === "inbox" ? `${group.title} — padrão` : group.title;
      const selected = group.id === selectedGroupID ? "selected" : "";
      return `<option value="${escapeAttribute(group.id)}" ${selected}>${escapeHtml(label)}</option>`;
    })
    .join("");
  elements.groupSelect.disabled = panelState.groups.length === 0;

  // Preview
  if (!capture) {
    elements.capturePreview.innerHTML = "";
    return;
  }

  const previewText = capture.url;

  elements.capturePreview.innerHTML = `
    <div class="capture-top">
      <span class="capture-badge">link</span>
      <span class="meta">${escapeHtml(previewTextLabel(capture))}</span>
    </div>
    <div class="capture-title">${escapeHtml(capture.title || capture.tabTitle || capture.url)}</div>
    <div class="capture-body">${escapeHtml(excerpt(previewText, 180))}</div>
  `;
}

/* ─── Settings mode ─── */

function renderSettingsMode() {
  const settings = panelState.settings || {};

  elements.autoTabsToggle.checked = Boolean(settings.autoImportTabs);
  elements.tabsTriggerSelect.value = settings.tabsImportTrigger || "startup";
  elements.autoHistoryToggle.checked = Boolean(settings.autoHistorySync);

  const activeHistoryMode = settings.historyBackfillMode || "from-now";
  elements.historyBackfillOptions.querySelectorAll("[data-history-mode]").forEach((option) => {
    option.classList.toggle("is-active", option.dataset.historyMode === activeHistoryMode);
  });

  if (settings.autoHistorySync) {
    const lastSync = settings.lastHistorySyncAt
      ? formatDateTime(settings.lastHistorySyncAt)
      : "aguardando novas visitas";
    const count = settings.historyItemsImportedToday || 0;
    elements.historySyncStatus.textContent = `Ativo · última sync: ${lastSync} · hoje: ${count}`;
  } else {
    elements.historySyncStatus.textContent = "Histórico automático pausado";
  }
}

/* ─── Scope dropdown ─── */

function toggleScopeDropdown() {
  uiState.scopeDropdownOpen = !uiState.scopeDropdownOpen;
  elements.scopeDropdown.classList.toggle("is-open", uiState.scopeDropdownOpen);
}

function closeScopeDropdown() {
  uiState.scopeDropdownOpen = false;
  elements.scopeDropdown.classList.remove("is-open");
}

/* ─── Helpers ─── */

function toggleGroup(groupID) {
  if (!groupID) return;
  if (uiState.query) return;

  if (uiState.openGroupIDs.has(groupID)) {
    uiState.openGroupIDs.delete(groupID);
  } else {
    uiState.openGroupIDs.add(groupID);
  }

  if (!uiState.openGroupIDs.size) {
    uiState.openGroupIDs.add(groupID);
  }

  renderTabsMode();
}

function groupSummary(group, visibleLinkCount) {
  const totalLinks = group.tabs.length;
  const linkCount = uiState.query ? visibleLinkCount : totalLinks;
  if (linkCount === 0) return "Grupo vazio";

  const noun = linkCount === 1 ? "link" : "links";
  if (uiState.query && linkCount !== totalLinks) {
    return `${linkCount} ${noun} encontrados`;
  }
  return `${linkCount} ${noun}`;
}

function groupAccent(group) {
  if (group.systemRole === "inbox") return "#8de0d1";

  const browserColorMap = {
    grey: "#9aa6b8",
    blue: "#7fb3ff",
    red: "#ff867c",
    yellow: "#ffd76c",
    green: "#7de0a0",
    pink: "#f59bff",
    purple: "#ae97ff",
    cyan: "#76e3f2",
    orange: "#ffb86c",
  };

  if (group.color && browserColorMap[group.color]) {
    return browserColorMap[group.color];
  }

  return hashColor(group.title);
}

function linkBadgeLabel(item) {
  const token = item.domain || item.title || item.url;
  return String(token).trim().charAt(0).toUpperCase() || "L";
}

function linkBadgeColor(item) {
  return hashColor(item.domain || item.title || item.url);
}

function previewTextLabel(capture) {
  return capture.captureKind === "selection" ? "Conteúdo salvo" : "Link atual";
}

function hashColor(seed) {
  const text = String(seed || "vindula");
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = (hash * 31 + text.charCodeAt(i)) % 360;
  }
  return `linear-gradient(145deg, hsl(${hash} 84% 76%), hsl(${(hash + 28) % 360} 76% 62%))`;
}

function setStatus(message, ok) {
  if (statusResetTimer) {
    clearTimeout(statusResetTimer);
  }

  elements.statusToast.textContent = message;
  elements.statusToast.className = "status-toast";

  if (message) {
    elements.statusToast.classList.add("is-visible");
    elements.statusToast.classList.add(ok ? "is-success" : "is-error");
    statusResetTimer = setTimeout(() => {
      elements.statusToast.classList.remove("is-visible");
    }, 3200);
  } else {
    elements.statusToast.classList.remove("is-visible");
  }
}

function excerpt(text, limit) {
  const normalized = String(text || "").replace(/\s+/g, " ").trim();
  if (normalized.length <= limit) return normalized;
  return `${normalized.slice(0, limit)}…`;
}

function scopeLabel(scope) {
  const labels = { all: "Tudo", groups: "Grupos", links: "Links" };
  return labels[scope] || String(scope).charAt(0).toUpperCase() + String(scope).slice(1);
}

function formatDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "desconhecida";
  }
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#96;");
}
