import * as THREE from "./vendor/three.module.min.js";

const root = document.getElementById("scene");
const summary = document.getElementById("summary");
const resetButton = document.getElementById("reset");
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x07100f, 0.0018);

const camera = new THREE.PerspectiveCamera(46, 1, 1, 2600);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
root.appendChild(renderer.domElement);

const graphGroup = new THREE.Group();
scene.add(graphGroup);

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const nodeMeshes = new Map();
const edgeLines = [];
const clock = new THREE.Clock();
const orbit = {
  yaw: -0.48,
  pitch: 0.42,
  distance: 520,
  target: new THREE.Vector3(0, 0, 0),
};
const drag = {
  active: false,
  mode: "orbit",
  startX: 0,
  startY: 0,
  x: 0,
  y: 0,
};

scene.add(new THREE.AmbientLight(0xa8f2dc, 1.15));
const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
keyLight.position.set(180, 260, 240);
scene.add(keyLight);
const rimLight = new THREE.PointLight(0x6bd7ff, 1200, 1200);
rimLight.position.set(-260, -140, 280);
scene.add(rimLight);

function resize() {
  const width = Math.max(root.clientWidth, 1);
  const height = Math.max(root.clientHeight, 1);
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
}

function updateCamera() {
  const cp = Math.cos(orbit.pitch);
  camera.position.set(
    orbit.target.x + Math.sin(orbit.yaw) * cp * orbit.distance,
    orbit.target.y + Math.sin(orbit.pitch) * orbit.distance,
    orbit.target.z + Math.cos(orbit.yaw) * cp * orbit.distance,
  );
  camera.lookAt(orbit.target);
}

function disposeObject(object) {
  object.traverse((child) => {
    if (child.geometry) child.geometry.dispose();
    if (child.material) {
      const materials = Array.isArray(child.material) ? child.material : [child.material];
      materials.forEach((material) => {
        if (material.map) material.map.dispose();
        material.dispose();
      });
    }
  });
}

function clearGraph() {
  for (const child of [...graphGroup.children]) {
    graphGroup.remove(child);
    disposeObject(child);
  }
  nodeMeshes.clear();
  edgeLines.length = 0;
}

function toneColor(node) {
  return new THREE.Color(node.color || "#8ae9d0");
}

function nodePosition(index, count, selected) {
  if (selected) return new THREE.Vector3(0, 0, 0);
  const golden = Math.PI * (3 - Math.sqrt(5));
  const y = count <= 1 ? 0 : 1 - (index / Math.max(count - 1, 1)) * 2;
  const radius = Math.sqrt(Math.max(0, 1 - y * y));
  const scale = 150 + Math.min(count, 48) * 4;
  return new THREE.Vector3(
    Math.cos(index * golden) * radius * scale,
    y * scale * 0.72,
    Math.sin(index * golden) * radius * scale * 0.62,
  );
}

function makeLabel(text, color, radius, selected) {
  const canvas = document.createElement("canvas");
  canvas.width = 448;
  canvas.height = 120;
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "rgba(7, 16, 15, 0.68)";
  roundedRect(ctx, 24, 32, 400, 56, 14);
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = selected ? 3 : 2;
  ctx.stroke();
  ctx.fillStyle = "#edf8f4";
  ctx.font = `${selected ? "700" : "600"} ${selected ? 28 : 24}px -apple-system, BlinkMacSystemFont, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const clipped = text.length > 26 ? `${text.slice(0, 23)}...` : text;
  ctx.fillText(clipped, 224, 60, 352);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.SpriteMaterial({ map: texture, transparent: true });
  const sprite = new THREE.Sprite(material);
  const labelWidth = Math.max(52, Math.min(selected ? 112 : 88, clipped.length * 3.1 + 26));
  sprite.scale.set(labelWidth, labelWidth * (canvas.height / canvas.width), 1);
  sprite.position.y = -(radius + (selected ? 22 : 16));
  return sprite;
}

function roundedRect(ctx, x, y, width, height, radius) {
  if (typeof ctx.roundRect === "function") {
    ctx.beginPath();
    ctx.roundRect(x, y, width, height, radius);
    return;
  }
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
}

function makeNode(node, index, count) {
  const color = toneColor(node);
  const geometry =
    node.shape === "diamond"
      ? new THREE.OctahedronGeometry(node.radius * 0.92, 1)
      : new THREE.SphereGeometry(node.radius, 34, 18);
  const material = new THREE.MeshPhysicalMaterial({
    color,
    emissive: color,
    emissiveIntensity: node.selected ? 0.42 : 0.18,
    roughness: 0.35,
    metalness: 0.1,
    clearcoat: 0.7,
  });
  const mesh = new THREE.Mesh(geometry, material);
  const base = nodePosition(index, count, node.selected);
  mesh.position.copy(base);
  mesh.userData = {
    id: node.id,
    base,
    phase: index * 0.71,
    selected: node.selected,
    radius: node.radius,
  };

  const halo = new THREE.Mesh(
    new THREE.SphereGeometry(node.radius * (node.selected ? 1.9 : 1.55), 32, 16),
    new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: node.selected ? 0.18 : 0.075,
      depthWrite: false,
    }),
  );
  mesh.add(halo);
  mesh.add(makeLabel(node.label, `#${color.getHexString()}`, node.radius, node.selected));
  return mesh;
}

function makeEdge(edge) {
  const from = nodeMeshes.get(edge.from);
  const to = nodeMeshes.get(edge.to);
  if (!from || !to) return null;

  const colors = {
    support: 0x63e6a4,
    evidence: 0xa9b8c9,
    conflict: 0xff6b7a,
    version: 0xf5b45b,
    relation: 0x6bd7ff,
  };
  const material = new THREE.LineBasicMaterial({
    color: colors[edge.tone] || colors.relation,
    transparent: true,
    opacity: edge.tone === "evidence" ? 0.3 : 0.55,
  });
  const geometry = new THREE.BufferGeometry().setFromPoints([from.position, to.position]);
  const line = new THREE.Line(geometry, material);
  line.userData = { from, to, tone: edge.tone, phase: edge.id.length * 0.1 };
  return line;
}

function fitGraph(nodes) {
  orbit.distance = Math.max(460, Math.min(940, 430 + nodes.length * 8));
  orbit.target.set(0, 0, 0);
  orbit.yaw = -0.48;
  orbit.pitch = 0.42;
  updateCamera();
}

function updateGraph(payload) {
  clearGraph();
  const nodes = payload.nodes || [];
  const edges = payload.edges || [];
  nodes.forEach((node, index) => {
    const mesh = makeNode(node, index, nodes.length);
    nodeMeshes.set(node.id, mesh);
    graphGroup.add(mesh);
  });
  edges.forEach((edge) => {
    const line = makeEdge(edge);
    if (line) {
      edgeLines.push(line);
      graphGroup.add(line);
    }
  });
  summary.textContent = `${payload.summary?.nodeCount || 0} nodes · ${payload.summary?.edgeCount || 0} edges`;
  fitGraph(nodes);
}

function postSelection(id) {
  window.webkit?.messageHandlers?.memoryGraph?.postMessage({ type: "selectNode", id });
}

function setPointer(event) {
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -(((event.clientY - rect.top) / rect.height) * 2 - 1);
}

renderer.domElement.addEventListener("pointerdown", (event) => {
  drag.active = true;
  drag.mode = event.shiftKey || event.button === 1 || event.button === 2 ? "pan" : "orbit";
  drag.startX = event.clientX;
  drag.startY = event.clientY;
  drag.x = event.clientX;
  drag.y = event.clientY;
  renderer.domElement.setPointerCapture(event.pointerId);
});

renderer.domElement.addEventListener("pointermove", (event) => {
  if (!drag.active) return;
  const dx = event.clientX - drag.x;
  const dy = event.clientY - drag.y;
  drag.x = event.clientX;
  drag.y = event.clientY;
  if (drag.mode === "pan") {
    const panScale = orbit.distance / 900;
    const right = new THREE.Vector3().setFromMatrixColumn(camera.matrix, 0).multiplyScalar(-dx * panScale);
    const up = new THREE.Vector3().setFromMatrixColumn(camera.matrix, 1).multiplyScalar(dy * panScale);
    orbit.target.add(right).add(up);
  } else {
    orbit.yaw -= dx * 0.006;
    orbit.pitch = Math.max(-1.15, Math.min(1.15, orbit.pitch - dy * 0.006));
  }
  updateCamera();
});

renderer.domElement.addEventListener("pointerup", (event) => {
  const moved = Math.abs(event.clientX - drag.startX) + Math.abs(event.clientY - drag.startY);
  drag.active = false;
  if (moved > 4) return;
  setPointer(event);
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObjects([...nodeMeshes.values()], false);
  if (hits[0]?.object?.userData?.id) postSelection(hits[0].object.userData.id);
});

renderer.domElement.addEventListener("wheel", (event) => {
  event.preventDefault();
  orbit.distance = Math.max(170, Math.min(1400, orbit.distance + event.deltaY * 0.52));
  updateCamera();
}, { passive: false });

renderer.domElement.addEventListener("contextmenu", (event) => event.preventDefault());
resetButton.addEventListener("click", () => fitGraph([...nodeMeshes.values()]));
window.addEventListener("resize", resize);

function animate() {
  requestAnimationFrame(animate);
  const elapsed = clock.getElapsedTime();
  for (const mesh of nodeMeshes.values()) {
    const { base, phase, selected, radius } = mesh.userData;
    mesh.position.set(
      base.x + Math.sin(elapsed * 0.9 + phase) * 7,
      base.y + Math.sin(elapsed * 1.15 + phase) * 10,
      base.z + Math.cos(elapsed * 0.75 + phase) * 7,
    );
    const pulse = selected ? 1 + Math.sin(elapsed * 2.2) * 0.07 : 1 + Math.sin(elapsed * 1.3 + phase) * 0.025;
    mesh.scale.setScalar(pulse);
    mesh.rotation.y += 0.003 + radius * 0.00004;
  }
  edgeLines.forEach((line) => {
    const { from, to, phase } = line.userData;
    line.geometry.setFromPoints([from.position, to.position]);
    line.material.opacity = 0.32 + Math.sin(elapsed * 1.8 + phase) * 0.16;
  });
  renderer.render(scene, camera);
}

window.MemoryGraphScene = { updateGraph };
resize();
updateCamera();
animate();
window.webkit?.messageHandlers?.memoryGraph?.postMessage({ type: "sceneReady" });
